#include <initguid.h>
#include <windows.h>
#include <d3d9.h>
#include <cstdio>
#include <cstring>

typedef IDirect3D9* (WINAPI* Direct3DCreate9_t)(UINT SDKVersion);

HMODULE g_OriginalD3D9 = nullptr;
Direct3DCreate9_t g_OriginalDirect3DCreate9 = nullptr;

float g_VSConst[256][4] = {};
bool g_CaptureFrame = false;
int g_CapturedDraws = 0;
int g_DeclCount = 0;

void LogMatrixDump(const char* text) {
    FILE* f = std::fopen("ss3_matrices.log", "a");
    if (f) {
        std::fprintf(f, "%s", text);
        std::fclose(f);
    }
}

class ProxyIDirect3DDevice9 : public IDirect3DDevice9 {
private:
    IDirect3DDevice9* m_Device;
public:
    ProxyIDirect3DDevice9(IDirect3DDevice9* pDevice) : m_Device(pDevice) {}

    HRESULT STDMETHODCALLTYPE GetDeviceCaps(D3DCAPS9* pCaps) override {
        HRESULT hr = m_Device->GetDeviceCaps(pCaps);
        if (SUCCEEDED(hr) && pCaps) {
            pCaps->VertexShaderVersion = D3DVS_VERSION(2, 0);
            pCaps->PixelShaderVersion = D3DPS_VERSION(2, 0);
            pCaps->MaxVertexShaderConst = 256;
            pCaps->PixelShader1xMaxValue = 65535.0f;
            pCaps->VS20Caps.Caps = 0;
            pCaps->VS20Caps.DynamicFlowControlDepth = 0;
            pCaps->VS20Caps.NumTemps = 12;
            pCaps->VS20Caps.StaticFlowControlDepth = 0;
            pCaps->PS20Caps.Caps = 0;
            pCaps->PS20Caps.DynamicFlowControlDepth = 0;
            pCaps->PS20Caps.NumTemps = 12;
            pCaps->PS20Caps.StaticFlowControlDepth = 0;
            pCaps->PS20Caps.NumInstructionSlots = 96;
        }
        return hr;
    }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObj) override { return m_Device->QueryInterface(riid, ppvObj); }
    ULONG STDMETHODCALLTYPE AddRef() override { return m_Device->AddRef(); }
    ULONG STDMETHODCALLTYPE Release() override { ULONG res = m_Device->Release(); if (res == 0) delete this; return res; }
    HRESULT STDMETHODCALLTYPE TestCooperativeLevel() override { return m_Device->TestCooperativeLevel(); }
    UINT STDMETHODCALLTYPE GetAvailableTextureMem() override { return m_Device->GetAvailableTextureMem(); }
    HRESULT STDMETHODCALLTYPE EvictManagedResources() override { return m_Device->EvictManagedResources(); }
    HRESULT STDMETHODCALLTYPE GetDirect3D(IDirect3D9** ppD3D9) override { return m_Device->GetDirect3D(ppD3D9); }
    HRESULT STDMETHODCALLTYPE GetDisplayMode(UINT iSwapChain, D3DDISPLAYMODE* pMode) override { return m_Device->GetDisplayMode(iSwapChain, pMode); }
    HRESULT STDMETHODCALLTYPE GetCreationParameters(D3DDEVICE_CREATION_PARAMETERS* pParameters) override { return m_Device->GetCreationParameters(pParameters); }
    HRESULT STDMETHODCALLTYPE SetCursorProperties(UINT XHotSpot, UINT YHotSpot, IDirect3DSurface9* pCursorBitmap) override { return m_Device->SetCursorProperties(XHotSpot, YHotSpot, pCursorBitmap); }
    void STDMETHODCALLTYPE SetCursorPosition(int X, int Y, DWORD Flags) override { m_Device->SetCursorPosition(X, Y, Flags); }
    BOOL STDMETHODCALLTYPE ShowCursor(BOOL bShow) override { return m_Device->ShowCursor(bShow); }
    HRESULT STDMETHODCALLTYPE CreateAdditionalSwapChain(D3DPRESENT_PARAMETERS* pPresentationParameters, IDirect3DSwapChain9** pSwapChain) override { return m_Device->CreateAdditionalSwapChain(pPresentationParameters, pSwapChain); }
    HRESULT STDMETHODCALLTYPE GetSwapChain(UINT iSwapChain, IDirect3DSwapChain9** pSwapChain) override { return m_Device->GetSwapChain(iSwapChain, pSwapChain); }
    UINT STDMETHODCALLTYPE GetNumberOfSwapChains() override { return m_Device->GetNumberOfSwapChains(); }
    HRESULT STDMETHODCALLTYPE Reset(D3DPRESENT_PARAMETERS* pPresentationParameters) override { return m_Device->Reset(pPresentationParameters); }
    HRESULT STDMETHODCALLTYPE Present(CONST RECT* pSourceRect, CONST RECT* pDestRect, HWND hDestWindowOverride, CONST RGNDATA* pDirtyRegion) override {
        if (g_CaptureFrame) {
            g_CaptureFrame = false;
            LogMatrixDump("=== END OF CAPTURED FRAME ===\n\n");
            Beep(800, 150);
        } else if (GetAsyncKeyState(VK_F10) & 1) {
            g_CaptureFrame = true;
            g_CapturedDraws = 0;
            LogMatrixDump("=== START OF CAPTURED FRAME (F10) ===\n");
        }
        return m_Device->Present(pSourceRect, pDestRect, hDestWindowOverride, pDirtyRegion);
    }
    HRESULT STDMETHODCALLTYPE GetBackBuffer(UINT iSwapChain, UINT iBackBuffer, D3DBACKBUFFER_TYPE Type, IDirect3DSurface9** ppBackBuffer) override { return m_Device->GetBackBuffer(iSwapChain, iBackBuffer, Type, ppBackBuffer); }
    HRESULT STDMETHODCALLTYPE GetRasterStatus(UINT iSwapChain, D3DRASTER_STATUS* pRasterStatus) override { return m_Device->GetRasterStatus(iSwapChain, pRasterStatus); }
    HRESULT STDMETHODCALLTYPE SetDialogBoxMode(BOOL bEnableDialogs) override { return m_Device->SetDialogBoxMode(bEnableDialogs); }
    void STDMETHODCALLTYPE SetGammaRamp(UINT iSwapChain, DWORD Flags, CONST D3DGAMMARAMP* pRamp) override { m_Device->SetGammaRamp(iSwapChain, Flags, pRamp); }
    void STDMETHODCALLTYPE GetGammaRamp(UINT iSwapChain, D3DGAMMARAMP* pRamp) override { m_Device->GetGammaRamp(iSwapChain, pRamp); }
    HRESULT STDMETHODCALLTYPE CreateTexture(UINT Width, UINT Height, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DTexture9** ppTexture, HANDLE* pSharedHandle) override { return m_Device->CreateTexture(Width, Height, Levels, Usage, Format, Pool, ppTexture, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateVolumeTexture(UINT Width, UINT Height, UINT Depth, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DVolumeTexture9** ppVolumeTexture, HANDLE* pSharedHandle) override { return m_Device->CreateVolumeTexture(Width, Height, Depth, Levels, Usage, Format, Pool, ppVolumeTexture, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateCubeTexture(UINT EdgeLength, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DCubeTexture9** ppCubeTexture, HANDLE* pSharedHandle) override { return m_Device->CreateCubeTexture(EdgeLength, Levels, Usage, Format, Pool, ppCubeTexture, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateVertexBuffer(UINT Length, DWORD Usage, DWORD FVF, D3DPOOL Pool, IDirect3DVertexBuffer9** ppVertexBuffer, HANDLE* pSharedHandle) override { return m_Device->CreateVertexBuffer(Length, Usage, FVF, Pool, ppVertexBuffer, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateIndexBuffer(UINT Length, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DIndexBuffer9** ppIndexBuffer, HANDLE* pSharedHandle) override { return m_Device->CreateIndexBuffer(Length, Usage, Format, Pool, ppIndexBuffer, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateRenderTarget(UINT Width, UINT Height, D3DFORMAT Format, D3DMULTISAMPLE_TYPE MultiSample, DWORD MultisampleQuality, BOOL Lockable, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle) override { return m_Device->CreateRenderTarget(Width, Height, Format, MultiSample, MultisampleQuality, Lockable, ppSurface, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE CreateDepthStencilSurface(UINT Width, UINT Height, D3DFORMAT Format, D3DMULTISAMPLE_TYPE MultiSample, DWORD MultisampleQuality, BOOL Discard, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle) override { return m_Device->CreateDepthStencilSurface(Width, Height, Format, MultiSample, MultisampleQuality, Discard, ppSurface, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE UpdateSurface(IDirect3DSurface9* pSourceSurface, CONST RECT* pSourceRect, IDirect3DSurface9* pDestinationSurface, CONST POINT* pDestPoint) override { return m_Device->UpdateSurface(pSourceSurface, pSourceRect, pDestinationSurface, pDestPoint); }
    HRESULT STDMETHODCALLTYPE UpdateTexture(IDirect3DBaseTexture9* pSourceTexture, IDirect3DBaseTexture9* pDestinationTexture) override { return m_Device->UpdateTexture(pSourceTexture, pDestinationTexture); }
    HRESULT STDMETHODCALLTYPE GetRenderTargetData(IDirect3DSurface9* pRenderTarget, IDirect3DSurface9* pDestSurface) override { return m_Device->GetRenderTargetData(pRenderTarget, pDestSurface); }
    HRESULT STDMETHODCALLTYPE GetFrontBufferData(UINT iSwapChain, IDirect3DSurface9* pDestSurface) override { return m_Device->GetFrontBufferData(iSwapChain, pDestSurface); }
    HRESULT STDMETHODCALLTYPE StretchRect(IDirect3DSurface9* pSourceSurface, CONST RECT* pSourceRect, IDirect3DSurface9* pDestinationSurface, CONST RECT* pDestRect, D3DTEXTUREFILTERTYPE Filter) override { return m_Device->StretchRect(pSourceSurface, pSourceRect, pDestinationSurface, pDestRect, Filter); }
    HRESULT STDMETHODCALLTYPE ColorFill(IDirect3DSurface9* pSurface, CONST RECT* pRect, D3DCOLOR color) override { return m_Device->ColorFill(pSurface, pRect, color); }
    HRESULT STDMETHODCALLTYPE CreateOffscreenPlainSurface(UINT Width, UINT Height, D3DFORMAT Format, D3DPOOL Pool, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle) override { return m_Device->CreateOffscreenPlainSurface(Width, Height, Format, Pool, ppSurface, pSharedHandle); }
    HRESULT STDMETHODCALLTYPE SetRenderTarget(DWORD RenderTargetIndex, IDirect3DSurface9* pRenderTarget) override { return m_Device->SetRenderTarget(RenderTargetIndex, pRenderTarget); }
    HRESULT STDMETHODCALLTYPE GetRenderTarget(DWORD RenderTargetIndex, IDirect3DSurface9** ppRenderTarget) override { return m_Device->GetRenderTarget(RenderTargetIndex, ppRenderTarget); }
    HRESULT STDMETHODCALLTYPE SetDepthStencilSurface(IDirect3DSurface9* pNewZStencil) override { return m_Device->SetDepthStencilSurface(pNewZStencil); }
    HRESULT STDMETHODCALLTYPE GetDepthStencilSurface(IDirect3DSurface9** ppZStencilSurface) override { return m_Device->GetDepthStencilSurface(ppZStencilSurface); }
    HRESULT STDMETHODCALLTYPE BeginScene() override { return m_Device->BeginScene(); }
    HRESULT STDMETHODCALLTYPE EndScene() override { return m_Device->EndScene(); }
    HRESULT STDMETHODCALLTYPE Clear(DWORD Count, CONST D3DRECT* pRects, DWORD Flags, D3DCOLOR Color, float Z, DWORD Stencil) override { return m_Device->Clear(Count, pRects, Flags, Color, Z, Stencil); }
    HRESULT STDMETHODCALLTYPE SetTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX* pMatrix) override { return m_Device->SetTransform(State, pMatrix); }
    HRESULT STDMETHODCALLTYPE GetTransform(D3DTRANSFORMSTATETYPE State, D3DMATRIX* pMatrix) override { return m_Device->GetTransform(State, pMatrix); }
    HRESULT STDMETHODCALLTYPE MultiplyTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX* pMatrix) override { return m_Device->MultiplyTransform(State, pMatrix); }
    HRESULT STDMETHODCALLTYPE SetViewport(CONST D3DVIEWPORT9* pViewport) override { return m_Device->SetViewport(pViewport); }
    HRESULT STDMETHODCALLTYPE GetViewport(D3DVIEWPORT9* pViewport) override { return m_Device->GetViewport(pViewport); }
    HRESULT STDMETHODCALLTYPE SetMaterial(CONST D3DMATERIAL9* pMaterial) override { return m_Device->SetMaterial(pMaterial); }
    HRESULT STDMETHODCALLTYPE GetMaterial(D3DMATERIAL9* pMaterial) override { return m_Device->GetMaterial(pMaterial); }
    HRESULT STDMETHODCALLTYPE SetLight(DWORD Index, CONST D3DLIGHT9* pLight) override { return m_Device->SetLight(Index, pLight); }
    HRESULT STDMETHODCALLTYPE GetLight(DWORD Index, D3DLIGHT9* pLight) override { return m_Device->GetLight(Index, pLight); }
    HRESULT STDMETHODCALLTYPE LightEnable(DWORD Index, BOOL Enable) override { return m_Device->LightEnable(Index, Enable); }
HRESULT STDMETHODCALLTYPE GetLightEnable(DWORD Index, BOOL* pEnable) override { return m_Device->GetLightEnable(Index, pEnable); }
HRESULT STDMETHODCALLTYPE SetClipPlane(DWORD Index, CONST float* pPlane) override { return m_Device->SetClipPlane(Index, pPlane); }
HRESULT STDMETHODCALLTYPE GetClipPlane(DWORD Index, float* pPlane) override { return m_Device->GetClipPlane(Index, pPlane); }
HRESULT STDMETHODCALLTYPE SetRenderState(D3DRENDERSTATETYPE State, DWORD Value) override { return m_Device->SetRenderState(State, Value); }
HRESULT STDMETHODCALLTYPE GetRenderState(D3DRENDERSTATETYPE State, DWORD* pValue) override { return m_Device->GetRenderState(State, pValue); }
HRESULT STDMETHODCALLTYPE CreateStateBlock(D3DSTATEBLOCKTYPE Type, IDirect3DStateBlock9** ppStateBlock) override { return m_Device->CreateStateBlock(Type, ppStateBlock); }
HRESULT STDMETHODCALLTYPE BeginStateBlock() override { return m_Device->BeginStateBlock(); }
HRESULT STDMETHODCALLTYPE EndStateBlock(IDirect3DStateBlock9** ppSB) override { return m_Device->EndStateBlock(ppSB); }
HRESULT STDMETHODCALLTYPE SetClipStatus(CONST D3DCLIPSTATUS9* pClipStatus) override { return m_Device->SetClipStatus(pClipStatus); }
HRESULT STDMETHODCALLTYPE GetClipStatus(D3DCLIPSTATUS9* pClipStatus) override { return m_Device->GetClipStatus(pClipStatus); }
HRESULT STDMETHODCALLTYPE GetTexture(DWORD Stage, IDirect3DBaseTexture9** ppTexture) override { return m_Device->GetTexture(Stage, ppTexture); }
HRESULT STDMETHODCALLTYPE SetTexture(DWORD Stage, IDirect3DBaseTexture9* pTexture) override { return m_Device->SetTexture(Stage, pTexture); }
HRESULT STDMETHODCALLTYPE GetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD* pValue) override { return m_Device->GetTextureStageState(Stage, Type, pValue); }
HRESULT STDMETHODCALLTYPE SetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD Value) override { return m_Device->SetTextureStageState(Stage, Type, Value); }
HRESULT STDMETHODCALLTYPE GetSamplerState(DWORD Sampler, D3DSAMPLERSTATETYPE Type, DWORD* pValue) override { return m_Device->GetSamplerState(Sampler, Type, pValue); }
HRESULT STDMETHODCALLTYPE SetSamplerState(DWORD Sampler, D3DSAMPLERSTATETYPE Type, DWORD Value) override { return m_Device->SetSamplerState(Sampler, Type, Value); }
HRESULT STDMETHODCALLTYPE ValidateDevice(DWORD* pNumPasses) override { return m_Device->ValidateDevice(pNumPasses); }
HRESULT STDMETHODCALLTYPE SetPaletteEntries(UINT PaletteNumber, CONST PALETTEENTRY* pEntries) override { return m_Device->SetPaletteEntries(PaletteNumber, pEntries); }
HRESULT STDMETHODCALLTYPE GetPaletteEntries(UINT PaletteNumber, PALETTEENTRY* pEntries) override { return m_Device->GetPaletteEntries(PaletteNumber, pEntries); }
HRESULT STDMETHODCALLTYPE SetCurrentTexturePalette(UINT PaletteNumber) override { return m_Device->SetCurrentTexturePalette(PaletteNumber); }
HRESULT STDMETHODCALLTYPE GetCurrentTexturePalette(UINT* PaletteNumber) override { return m_Device->GetCurrentTexturePalette(PaletteNumber); }
HRESULT STDMETHODCALLTYPE SetScissorRect(CONST RECT* pRect) override { return m_Device->SetScissorRect(pRect); }
HRESULT STDMETHODCALLTYPE GetScissorRect(RECT* pRect) override { return m_Device->GetScissorRect(pRect); }
HRESULT STDMETHODCALLTYPE SetSoftwareVertexProcessing(BOOL bSoftware) override { return m_Device->SetSoftwareVertexProcessing(bSoftware); }
BOOL STDMETHODCALLTYPE GetSoftwareVertexProcessing() override { return m_Device->GetSoftwareVertexProcessing(); }
HRESULT STDMETHODCALLTYPE SetNPatchMode(float nSegments) override { return m_Device->SetNPatchMode(nSegments); }
float STDMETHODCALLTYPE GetNPatchMode() override { return m_Device->GetNPatchMode(); }
HRESULT STDMETHODCALLTYPE DrawPrimitive(D3DPRIMITIVETYPE PrimitiveType, UINT StartVertex, UINT PrimitiveCount) override { return m_Device->DrawPrimitive(PrimitiveType, StartVertex, PrimitiveCount); }
HRESULT STDMETHODCALLTYPE DrawIndexedPrimitive(D3DPRIMITIVETYPE PrimitiveType, INT BaseVertexIndex, UINT MinVertexIndex, UINT NumVertices, UINT startIndex, UINT primCount) override {
if (g_CaptureFrame && g_CapturedDraws < 5 && primCount > 10) {
g_CapturedDraws++;
char hdr[128];
std::snprintf(hdr, sizeof(hdr), "\n--- DrawIndexedPrimitive #%d (NumVertices=%u, primCount=%u) ---\n", g_CapturedDraws, NumVertices, primCount);
LogMatrixDump(hdr);
for (int r = 0; r < 32; r++) {
char line[128];
std::snprintf(line, sizeof(line), "c%02d: %10.4f  %10.4f  %10.4f  %10.4f\n", r, g_VSConst[r][0], g_VSConst[r][1], g_VSConst[r][2], g_VSConst[r][3]);
LogMatrixDump(line);
}
}
return m_Device->DrawIndexedPrimitive(PrimitiveType, BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
}
HRESULT STDMETHODCALLTYPE DrawPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT PrimitiveCount, CONST void* pVertexStreamZeroData, UINT VertexStreamZeroStride) override { return m_Device->DrawPrimitiveUP(PrimitiveType, PrimitiveCount, pVertexStreamZeroData, VertexStreamZeroStride); }
HRESULT STDMETHODCALLTYPE DrawIndexedPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT MinVertexIndex, UINT NumVertices, UINT PrimitiveCount, CONST void* pIndexData, D3DFORMAT IndexDataFormat, CONST void* pVertexStreamZeroData, UINT VertexStreamZeroStride) override { return m_Device->DrawIndexedPrimitiveUP(PrimitiveType, MinVertexIndex, NumVertices, PrimitiveCount, pIndexData, IndexDataFormat, pVertexStreamZeroData, VertexStreamZeroStride); }
HRESULT STDMETHODCALLTYPE ProcessVertices(UINT SrcStartIndex, UINT DestIndex, UINT VertexCount, IDirect3DVertexBuffer9* pDestBuffer, IDirect3DVertexDeclaration9* pVertexDeclaration, DWORD Flags) override { return m_Device->ProcessVertices(SrcStartIndex, DestIndex, VertexCount, pDestBuffer, pVertexDeclaration, Flags); }
HRESULT STDMETHODCALLTYPE CreateVertexDeclaration(CONST D3DVERTEXELEMENT9* pVertexElements, IDirect3DVertexDeclaration9** ppDecl) override {
if (pVertexElements && g_DeclCount < 15) {
g_DeclCount++;
char hdr[64];
std::snprintf(hdr, sizeof(hdr), "[VertexDecl #%d]\n", g_DeclCount);
LogMatrixDump(hdr);
for (int i = 0; pVertexElements[i].Stream != 0xFF && i < 16; i++) {
char el[128];
std::snprintf(el, sizeof(el), "  Stream=%u Offset=%u Type=%u Usage=%u UsageIdx=%u\n",
pVertexElements[i].Stream, pVertexElements[i].Offset, pVertexElements[i].Type,
pVertexElements[i].Usage, pVertexElements[i].UsageIndex);
LogMatrixDump(el);
}
}
return m_Device->CreateVertexDeclaration(pVertexElements, ppDecl);
}
HRESULT STDMETHODCALLTYPE SetVertexDeclaration(IDirect3DVertexDeclaration9* pDecl) override { return m_Device->SetVertexDeclaration(pDecl); }
HRESULT STDMETHODCALLTYPE GetVertexDeclaration(IDirect3DVertexDeclaration9** ppDecl) override { return m_Device->GetVertexDeclaration(ppDecl); }
HRESULT STDMETHODCALLTYPE SetFVF(DWORD FVF) override { return m_Device->SetFVF(FVF); }
HRESULT STDMETHODCALLTYPE GetFVF(DWORD* pFVF) override { return m_Device->GetFVF(pFVF); }
HRESULT STDMETHODCALLTYPE SetStreamSource(UINT StreamNumber, IDirect3DVertexBuffer9* pStreamData, UINT OffsetInBytes, UINT Stride) override { return m_Device->SetStreamSource(StreamNumber, pStreamData, OffsetInBytes, Stride); }
HRESULT STDMETHODCALLTYPE GetStreamSource(UINT StreamNumber, IDirect3DVertexBuffer9** ppStreamData, UINT* pOffsetInBytes, UINT* pStride) override { return m_Device->GetStreamSource(StreamNumber, ppStreamData, pOffsetInBytes, pStride); }
HRESULT STDMETHODCALLTYPE SetStreamSourceFreq(UINT StreamNumber, UINT Setting) override { return m_Device->SetStreamSourceFreq(StreamNumber, Setting); }
HRESULT STDMETHODCALLTYPE GetStreamSourceFreq(UINT StreamNumber, UINT* pSetting) override { return m_Device->GetStreamSourceFreq(StreamNumber, pSetting); }
HRESULT STDMETHODCALLTYPE SetIndices(IDirect3DIndexBuffer9* pIndexData) override { return m_Device->SetIndices(pIndexData); }
HRESULT STDMETHODCALLTYPE GetIndices(IDirect3DIndexBuffer9** ppIndexData) override { return m_Device->GetIndices(ppIndexData); }
HRESULT STDMETHODCALLTYPE CreateVertexShader(CONST DWORD* pFunction, IDirect3DVertexShader9** ppShader) override { return m_Device->CreateVertexShader(pFunction, ppShader); }
HRESULT STDMETHODCALLTYPE SetVertexShader(IDirect3DVertexShader9* pShader) override { return m_Device->SetVertexShader(pShader); }
HRESULT STDMETHODCALLTYPE GetVertexShader(IDirect3DVertexShader9** ppShader) override { return m_Device->GetVertexShader(ppShader); }
HRESULT STDMETHODCALLTYPE SetVertexShaderConstantF(UINT StartRegister, CONST float* pConstantData, UINT Vector4fCount) override {
if (pConstantData && StartRegister < 256) {
UINT count = (StartRegister + Vector4fCount > 256) ? (256 - StartRegister) : Vector4fCount;
std::memcpy(&g_VSConst[StartRegister][0], pConstantData, count * 4 * sizeof(float));
}
return m_Device->SetVertexShaderConstantF(StartRegister, pConstantData, Vector4fCount);
}
HRESULT STDMETHODCALLTYPE GetVertexShaderConstantF(UINT StartRegister, float* pConstantData, UINT Vector4fCount) override { return m_Device->GetVertexShaderConstantF(StartRegister, pConstantData, Vector4fCount); }
HRESULT STDMETHODCALLTYPE SetVertexShaderConstantI(UINT StartRegister, CONST int* pConstantData, UINT Vector4iCount) override { return m_Device->SetVertexShaderConstantI(StartRegister, pConstantData, Vector4iCount); }
HRESULT STDMETHODCALLTYPE GetVertexShaderConstantI(UINT StartRegister, int* pConstantData, UINT Vector4iCount) override { return m_Device->GetVertexShaderConstantI(StartRegister, pConstantData, Vector4iCount); }
HRESULT STDMETHODCALLTYPE SetVertexShaderConstantB(UINT StartRegister, CONST BOOL* pConstantData, UINT BoolCount) override { return m_Device->SetVertexShaderConstantB(StartRegister, pConstantData, BoolCount); }
HRESULT STDMETHODCALLTYPE GetVertexShaderConstantB(UINT StartRegister, BOOL* pConstantData, UINT BoolCount) override { return m_Device->GetVertexShaderConstantB(StartRegister, pConstantData, BoolCount); }
HRESULT STDMETHODCALLTYPE CreatePixelShader(CONST DWORD* pFunction, IDirect3DPixelShader9** ppShader) override { return m_Device->CreatePixelShader(pFunction, ppShader); }
HRESULT STDMETHODCALLTYPE SetPixelShader(IDirect3DPixelShader9* pShader) override { return m_Device->SetPixelShader(pShader); }
HRESULT STDMETHODCALLTYPE GetPixelShader(IDirect3DPixelShader9** ppShader) override { return m_Device->GetPixelShader(ppShader); }
HRESULT STDMETHODCALLTYPE SetPixelShaderConstantF(UINT StartRegister, CONST float* pConstantData, UINT Vector4fCount) override { return m_Device->SetPixelShaderConstantF(StartRegister, pConstantData, Vector4fCount); }
HRESULT STDMETHODCALLTYPE GetPixelShaderConstantF(UINT StartRegister, float* pConstantData, UINT Vector4fCount) override { return m_Device->GetPixelShaderConstantF(StartRegister, pConstantData, Vector4fCount); }
HRESULT STDMETHODCALLTYPE SetPixelShaderConstantI(UINT StartRegister, CONST int* pConstantData, UINT Vector4iCount) override { return m_Device->SetPixelShaderConstantI(StartRegister, pConstantData, Vector4iCount); }
HRESULT STDMETHODCALLTYPE GetPixelShaderConstantI(UINT StartRegister, int* pConstantData, UINT Vector4iCount) override { return m_Device->GetPixelShaderConstantI(StartRegister, pConstantData, Vector4iCount); }
HRESULT STDMETHODCALLTYPE SetPixelShaderConstantB(UINT StartRegister, CONST BOOL* pConstantData, UINT BoolCount) override { return m_Device->SetPixelShaderConstantB(StartRegister, pConstantData, BoolCount); }
HRESULT STDMETHODCALLTYPE GetPixelShaderConstantB(UINT StartRegister, BOOL* pConstantData, UINT BoolCount) override { return m_Device->GetPixelShaderConstantB(StartRegister, pConstantData, BoolCount); }
HRESULT STDMETHODCALLTYPE DrawRectPatch(UINT Handle, CONST float* pNumSegs, CONST D3DRECTPATCH_INFO* pRectPatchInfo) override { return m_Device->DrawRectPatch(Handle, pNumSegs, pRectPatchInfo); }
HRESULT STDMETHODCALLTYPE DrawTriPatch(UINT Handle, CONST float* pNumSegs, CONST D3DTRIPATCH_INFO* pTriPatchInfo) override { return m_Device->DrawTriPatch(Handle, pNumSegs, pTriPatchInfo); }
HRESULT STDMETHODCALLTYPE DeletePatch(UINT Handle) override { return m_Device->DeletePatch(Handle); }
HRESULT STDMETHODCALLTYPE CreateQuery(D3DQUERYTYPE Type, IDirect3DQuery9** ppQuery) override { return m_Device->CreateQuery(Type, ppQuery); }
};
class ProxyIDirect3D9 : public IDirect3D9 {
private:
    IDirect3D9* m_D3D9;
public:
    ProxyIDirect3D9(IDirect3D9* pD3D9) : m_D3D9(pD3D9) {}

    HRESULT STDMETHODCALLTYPE GetDeviceCaps(UINT Adapter, D3DDEVTYPE DeviceType, D3DCAPS9* pCaps) override {
        HRESULT hr = m_D3D9->GetDeviceCaps(Adapter, DeviceType, pCaps);
        if (SUCCEEDED(hr) && pCaps) {
            pCaps->VertexShaderVersion = D3DVS_VERSION(2, 0);
            pCaps->PixelShaderVersion = D3DPS_VERSION(2, 0);
            pCaps->MaxVertexShaderConst = 256;
            pCaps->PixelShader1xMaxValue = 65535.0f;
            pCaps->VS20Caps.Caps = 0;
            pCaps->VS20Caps.DynamicFlowControlDepth = 0;
            pCaps->VS20Caps.NumTemps = 12;
            pCaps->VS20Caps.StaticFlowControlDepth = 0;
            pCaps->PS20Caps.Caps = 0;
            pCaps->PS20Caps.DynamicFlowControlDepth = 0;
            pCaps->PS20Caps.NumTemps = 12;
            pCaps->PS20Caps.StaticFlowControlDepth = 0;
            pCaps->PS20Caps.NumInstructionSlots = 96;
        }
        return hr;
    }

    HRESULT STDMETHODCALLTYPE CreateDevice(UINT Adapter, D3DDEVTYPE DeviceType, HWND hFocusWindow, DWORD BehaviorFlags, D3DPRESENT_PARAMETERS* pPresentationParameters, IDirect3DDevice9** ppReturnedDeviceInterface) override {
        IDirect3DDevice9* realDevice = nullptr;
        HRESULT hr = m_D3D9->CreateDevice(Adapter, DeviceType, hFocusWindow, BehaviorFlags, pPresentationParameters, &realDevice);
        if (SUCCEEDED(hr) && realDevice) {
            *ppReturnedDeviceInterface = new ProxyIDirect3DDevice9(realDevice);
        }
        return hr;
    }

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObj) override { return m_D3D9->QueryInterface(riid, ppvObj); }
    ULONG STDMETHODCALLTYPE AddRef() override { return m_D3D9->AddRef(); }
    ULONG STDMETHODCALLTYPE Release() override { ULONG res = m_D3D9->Release(); if (res == 0) delete this; return res; }
    HRESULT STDMETHODCALLTYPE RegisterSoftwareDevice(void* pInitializeFunction) override { return m_D3D9->RegisterSoftwareDevice(pInitializeFunction); }
    UINT STDMETHODCALLTYPE GetAdapterCount() override { return m_D3D9->GetAdapterCount(); }
    HRESULT STDMETHODCALLTYPE GetAdapterIdentifier(UINT Adapter, DWORD Flags, D3DADAPTER_IDENTIFIER9* pIdentifier) override { return m_D3D9->GetAdapterIdentifier(Adapter, Flags, pIdentifier); }
    UINT STDMETHODCALLTYPE GetAdapterModeCount(UINT Adapter, D3DFORMAT Format) override { return m_D3D9->GetAdapterModeCount(Adapter, Format); }
    HRESULT STDMETHODCALLTYPE EnumAdapterModes(UINT Adapter, D3DFORMAT Format, UINT Mode, D3DDISPLAYMODE* pMode) override { return m_D3D9->EnumAdapterModes(Adapter, Format, Mode, pMode); }
    HRESULT STDMETHODCALLTYPE GetAdapterDisplayMode(UINT Adapter, D3DDISPLAYMODE* pMode) override { return m_D3D9->GetAdapterDisplayMode(Adapter, pMode); }
    HRESULT STDMETHODCALLTYPE CheckDeviceType(UINT Adapter, D3DDEVTYPE DevType, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, BOOL bWindowed) override { return m_D3D9->CheckDeviceType(Adapter, DevType, AdapterFormat, BackBufferFormat, bWindowed); }
    HRESULT STDMETHODCALLTYPE CheckDeviceFormat(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, DWORD Usage, D3DRESOURCETYPE RType, D3DFORMAT CheckFormat) override { return m_D3D9->CheckDeviceFormat(Adapter, DeviceType, AdapterFormat, Usage, RType, CheckFormat); }
    HRESULT STDMETHODCALLTYPE CheckDeviceMultiSampleType(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT SurfaceFormat, BOOL Windowed, D3DMULTISAMPLE_TYPE MultiSampleType, DWORD* pQualityLevels) override { return m_D3D9->CheckDeviceMultiSampleType(Adapter, DeviceType, SurfaceFormat, Windowed, MultiSampleType, pQualityLevels); }
    HRESULT STDMETHODCALLTYPE CheckDepthStencilMatch(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, D3DFORMAT RenderTargetFormat, D3DFORMAT DepthStencilFormat) override { return m_D3D9->CheckDepthStencilMatch(Adapter, DeviceType, AdapterFormat, RenderTargetFormat, DepthStencilFormat); }
    HRESULT STDMETHODCALLTYPE CheckDeviceFormatConversion(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT SourceFormat, D3DFORMAT TargetFormat) override { return m_D3D9->CheckDeviceFormatConversion(Adapter, DeviceType, SourceFormat, TargetFormat); }
    HMONITOR STDMETHODCALLTYPE GetAdapterMonitor(UINT Adapter) override { return m_D3D9->GetAdapterMonitor(Adapter); }
};

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        char sysPath[MAX_PATH];
        GetSystemDirectoryA(sysPath, MAX_PATH);
        std::strcat(sysPath, "\\d3d9.dll");
        g_OriginalD3D9 = LoadLibraryA(sysPath);
        if (g_OriginalD3D9) {
            g_OriginalDirect3DCreate9 = (Direct3DCreate9_t)GetProcAddress(g_OriginalD3D9, "Direct3DCreate9");
        }
    } else if (ul_reason_for_call == DLL_PROCESS_DETACH) {
        if (g_OriginalD3D9) FreeLibrary(g_OriginalD3D9);
    }
    return TRUE;
}

extern "C" IDirect3D9* WINAPI Direct3DCreate9(UINT SDKVersion) {
    if (!g_OriginalDirect3DCreate9) return nullptr;
    IDirect3D9* realD3D9 = g_OriginalDirect3DCreate9(SDKVersion);
    if (!realD3D9) return nullptr;
    return new ProxyIDirect3D9(realD3D9);
}